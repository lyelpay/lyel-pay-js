export const SANDBOX_BASE_URL = 'https://sandbox.lyelpay.com';
export const PROD_BASE_URL = 'https://api.lyelpay.com';

export const DEFAULT_HEADERS = {
  'Content-Type': 'application/json',
};
