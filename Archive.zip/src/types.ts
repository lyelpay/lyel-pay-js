export interface InitOptions {
    apiKey: string;
    env?: 'sandbox' | 'production';
}
  
export interface InitOtpParams {
    phoneNumber: string;
}
  
export interface VerifyOtpParams {
    phoneNumber: string;
    code: string;
}
  
export interface TransactionParams {
    amount: number;
    currency: string;
    description?: string;
    customerId: string;
}